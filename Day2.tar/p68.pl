
open(FH,"cmds.log");
open(WH,">>/var/log/test.log");

while($v = <FH>){    # reading data from <FILE>
	
	print WH $v; # writing data to FILE

}
close(FH);
close(WH);
