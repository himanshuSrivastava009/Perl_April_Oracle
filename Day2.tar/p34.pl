$Fname = "boot.log" ; 
$Findex = 1459;
$Futil  = 98.31;

@Finfo = ($Fname,$Findex,$Futil,"D1","D2",145,31.3); # array

print "@Finfo\n";
print "File name: $Finfo[0]\n";
print "File name: $Finfo[1]\n";
print "File name: $Finfo[2]\n";
print "-->$Finfo[9]\n"; # empty
print "$Finfo[-1]\n";
print "$Finfo[-2]\n";
print "$Finfo[-3]\n";


