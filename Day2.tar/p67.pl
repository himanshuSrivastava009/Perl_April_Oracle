
 $LB=`uptime`;

 $fs=`df`;
 
 open(WH,">>cmds.log"); # append operation

 print WH $LB; # writing data to FILE   Vs  print $LB; ->display to monitor
 print WH $fs; # writing data to FILE	Vs  print $fs; ->display to monitor

 close(WH);
