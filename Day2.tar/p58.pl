%hosts = () ; # empty hash
@K = keys(%hosts);
print "No.of items:",scalar(@K),"\n";  # A

$c = 0;
while($c < 5){
	print("Enter a host name:");
	chomp($h = <>);
	print("Enter $h IP-Address:");
	chomp($ip = <>);
	$hosts{$h}=$ip;  # adding new data to an existing hash	
	$c++;
}
@K = keys(%hosts);
print "No.of items:",scalar(@K),"\n";   # B

print("\nHost name \t IP-Address\n");
foreach $var (keys(%hosts)){
	print("$var -  $hosts{$var}\n");
}
