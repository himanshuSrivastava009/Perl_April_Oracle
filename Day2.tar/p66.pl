
 $LB="0.23";

 $fs="xfs file system";
 
 open(WH,">cmds.log"); # create a newFILE

 print WH $LB; # writing data to FILE   Vs  print $LB; ->display to monitor
 print WH $fs; # writing data to FILE	Vs  print $fs; ->display to monitor

 close(WH);
