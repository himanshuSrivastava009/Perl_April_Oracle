
open(FH,"/root/emp.csv");

while(<FH>){
	@a = grep(/sales/,$_);
	print "@a\n";
}
close(FH);

#########################################
@results=();

open(FH,"/root/emp.csv");

while(<FH>){
	@sales_dept=grep(/sales/,$_);
	push(@results,@sales_dept); # appending sales details to an existing array
}
close(FH);

print "@results\n"; # display sales emp details only
