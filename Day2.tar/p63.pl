

open(FH,"/root/emp.csv");

while($result = <FH>){ ###<== reading from File 
	print "$result";
	sleep 1;
}
close(FH);
=begin
while($r = <>){   #### <== Reading data from Keyboard
	print "$r";
}
=cut

