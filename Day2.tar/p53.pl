
%emp = (eid =>"e123",ename =>"Raj",edept =>"sales");

print "$emp{eid}\n";
print "$emp{ename}\n";
print "$emp{edept}\n";
print "\n";

@k = keys(%emp); # to get list of keys from hash

print "List of keys:\n";
foreach(@k){
	print "$_\n";
}

print "\n";
foreach $var (@k){
	print "$var   $emp{$var}\n";
}

print "No.of items:",scalar(@k),"\n";
