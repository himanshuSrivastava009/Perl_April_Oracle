
@k = keys(%ENV);

foreach $v (@k){
	print "$v -  $ENV{$v}\n";
	print "\n";
	sleep 1;
}
