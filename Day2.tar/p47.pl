
@arr=("D1","D2","D3",10,20,30);

foreach $var (@arr){
	print "$var\n";
}
print "\n\n";
foreach (@arr){
	print "$_\n"; # special variable $_
}

print "Working script file name:$0\n";

