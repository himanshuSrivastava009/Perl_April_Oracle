
@arr = qw(10 20 30 40 50 60 70 D1 D2 D3);

@r = @arr[2,5];
print "@r\n";

