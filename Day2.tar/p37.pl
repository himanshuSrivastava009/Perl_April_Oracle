
@files = ();

if(scalar(@files) == 0){
    print "Empty array\n";
} else {
    print "List of items:\n";
    foreach $var (@files){
	 print "-->$var\n";
    }
}
