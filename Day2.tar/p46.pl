

$s = "root:x:bin:usr:bash";

@arr = split(":",$s);

print "@arr\n";


@arr=("usr","x","bin","ksh");

$s = join(":",@arr);

print "\n$s\n";

