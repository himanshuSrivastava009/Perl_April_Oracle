
%emp=(eid =>123,ename =>"Raj", edept =>"sales", eplace =>"City");
=begin
@a = each(%emp);
print "@a\n";
@a = each(%emp);
print "@a\n";
@a = each(%emp);
print "@a\n";
=cut
#@K=keys(%emp);
#print "@K\n";
=begin
while(@a = each(%emp)){
	($k,$v) = @a;
	print "Key=$k  Value=$v\n";
}
=cut

while(($k,$v)=each(%emp)){
	print "Key = $k    Value = $v\n";
}
print "\n\n";

foreach $v (keys(%emp)){
	print "Key = $v   Value = $emp{$v}\n";
}


