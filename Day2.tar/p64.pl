
open(FH,"/root/emp.csv");

while(<FH>){
	print "$_";
}
close(FH);
print "\n\n";
open(FH,"/root/emp.csv");

while(<FH>){
	@a = split(",",$_);	
	print "$a[0] $a[1] $a[-1]\n";
}
close(FH);
