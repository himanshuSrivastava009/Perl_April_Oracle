
@arr1 = ("D1","D2","D3");

@arr2 = (D1,D2,D3);

@arr3 = (D1,
D2,
D3);
print "@arr3\n";
print "@arr2\n";

@arr4 = qw(D1	
D2
D3);
print "@arr4\n";

@arr5 = qw(10 20 3.2 D1 D2);
print "@arr5\n";

@arr6 = qw(100
200
300
400);
print "@arr6\n";
