@arr = ("D1","D2","D3","D4","D5","D6","D7");
#	0     1      2       3      4       5       6

print "@arr\n\n";
@removed_array = splice(@arr,3,2,("OL5","OL6"));
print "@arr\n"; # modified

print "removed items:@removed_array\n";


@removed_array = splice(@arr,3,2); # delete from 3rd index and 4th index
print "-->@arr\n"; # modified
print "@removed_array\n\n";

@removed_array=splice(@arr,3); 
print "--->@arr\n";
print "@removed_array\n";
