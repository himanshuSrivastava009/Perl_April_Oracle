@arr=(10,24,"D1","D2","Dx",45,99);

$s1 = scalar(@arr);

@b = @arr; # we can initialize from array ->array

$va = $arr[1]; # we  can initialize from scalar ->scalar

$s2 = @arr; # from array ->scalar(no.of array items)

print "\$s1 = $s1\n\$s2=$s2\n";
