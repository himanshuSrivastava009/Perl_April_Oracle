
open(FH,"/root/emp.csv");
$results =  <FH>; # read data from <FILE> - not a keyboard  then initialize to variable
print "$results"; # display to monitor
$results =  <FH>; # read data from <FILE> - not a keyboard  then initialize to variable
print "$results"; # display to monitor
close(FH);

