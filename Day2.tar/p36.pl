@arr=(10,24,"D1","D2","Dx",45,99);

# scalar(@input_array); -> $total_no.of_array_elements
# ------ ^^^^^^^^^^^^       ^^^^^^^^^^^^^^^^^^^^^^^^^^^
#
print "@arr\n";
print "Total no.of elements:",scalar(@arr),"\n";

@a1=(); # empty array
print "\nTotal no.of elements:",scalar(@a1),"\n";

$course="Perl5Programming";

# length($input_scalar) ->output_scalar(int)
# ------

print "Total no.of chars:",length($course),"\n";
