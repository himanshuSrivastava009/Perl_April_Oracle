@emps = ( "101,raj,sales,pune,1000","102,leo,prod,bglore,2000","103,anu,sales,pune,3000","104,paul,prod,hyd,4000");

$total=0;
foreach $var (@emps) {
      ($eid,$ename,$edept,$ecity,$ecost)=split(",",$var);
      print "Emp name is:$ename    Working dept is:$edept\n";
      print "-"x45;
      print "\n";
      $total = $total + $ecost;
}
print "\n Sum of Emps Cost is:$total
------------------------------------\n";
