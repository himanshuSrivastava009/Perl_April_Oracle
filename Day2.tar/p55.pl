@SIZE = (120,450,500,100,130) ;

$t = 0;
foreach $var (@SIZE){
	$t = $t + $var;
}
print "Sum of @SIZE is:$t \n";
