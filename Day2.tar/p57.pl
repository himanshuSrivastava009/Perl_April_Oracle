if(scalar(@ARGV) == 0 ){
	print "Usage :  Commandline argument is an empty argument\n";
	exit();
}
if(scalar(@ARGV) >1){
	print "Usage: Commandline argument allows single input file\n";
	exit();
}

if( "$ARGV[0]"  eq  "$0") {  # $0 - special variable - name of your file
	print "Usage:Commandline argument input file is not same as script file\n";
	exit();
}
$fname = shift(@ARGV);    #  <or> ($fname) = @ARGV;

if( -e $fname ){
       print "File name $fname is exists\n";
}else{
       print "File name $fname is not exists\n";
}

