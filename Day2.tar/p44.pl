
@sh=("csh","ash","bash","tcsh","zsh","ksh");

print "@sh\n";

@sa = sort(@sh);
print "\n@sa\n";

@nos=(450,1298,98,45,2590);

#@sb = sort(@nos);
#print "@sb\n";

@sb = sort({$a <=>$b}@nos); # spaceship operator $a <=> $b placeholder
print "@sb\n";

@sc = sort({$b <=>$a}@nos);
print "@sc\n";

@sd = sort({$a cmp $b}@sh); # same @sa = sort(@sh); - default ascending order
print "@sd\n";

@se = sort({$b cmp $a}@sh); 
print "@se\n";




