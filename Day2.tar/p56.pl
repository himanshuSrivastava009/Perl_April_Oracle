

@EMPs = ("101,raj,sales,pune,1000","102,kumar,prod,bglore,2000","103,anu,prod,mumbai,3000",
	"104,leo,sales,hyd,4000","105,theeb,hr,5000");

@results =  grep(/sales/,@EMPs);
 $total = 0;
foreach $var (@results){
	($eid,$ename,$edept,$ecity,$ecost) = split(",",$var);
	print "Emp name is:$ename  Working City is:$ecity\n";
	$total = $total + $ecost;
}
print "\n Sum of sales emp's Cost is:$total\n";
