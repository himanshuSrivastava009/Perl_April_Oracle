@hosts = () ; # empty array
print "A : No.of hosts:",scalar(@hosts),"\n";

$count = 0;

while ($count < 5){
      print "Enter a hostname:";
      chomp($h = <>);  # interface to keyboard
      push(@hosts,$h); # append operation   
      $count ++ ;
}
print "\nB : No.of hosts:",scalar(@hosts),"\n";
print "List of hosts details:-\n";
foreach $var (@hosts) {
	print "$var\n";
}
print "End of the line\n";
