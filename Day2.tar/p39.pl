@os = ("winx","Linux","sunos","minix");

print "Total no.of os:",scalar(@os),"\n";
print "@os\n";

unshift(@os,"unix");

print "Total no.of os:",scalar(@os),"\n";
print "@os\n";

push(@os,"OL9"); # like append

print "Total no.of os:",scalar(@os),"\n";
print "@os\n";

@files=("p1.c","p2.c","test1.java","test2.java","index.html");
print "Total no.of files:",scalar(@files),"\n";
print "@files\n";

$r = shift(@files); # remove 0th index
print "\$r = $r\n";
print "Total no.of files:",scalar(@files),"\n";
print "@files\n";


$r = pop(@files);  # remove last index
print "\$r = $r\n";
print "Total no.of files:",scalar(@files),"\n";
print "@files\n";

