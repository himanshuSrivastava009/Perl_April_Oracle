%emp = (eid =>"e123",ename =>"Raj",edept =>"sales");

print "$emp{eid}\n";
print "$emp{ename}\n";
print "$emp{edept}\n";

$emp{edept}="production"; # to modify an existing value

print "\n updated dept is:$emp{edept}\n";

$emp{eplace}="Bangalore"; # to add new data to an existing dict
print "$emp{ename} living city is:$emp{eplace}\n";
