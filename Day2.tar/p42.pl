
$emp = "userA,sales,pune,1230\n";
print "Total no.of chars:",length($emp),"\n";

@arr = split(",",$emp);
####
print "@arr\n";
print "No.of items:",scalar(@arr),"\n";

($ename,$edept,$ecity,$ecost) = split(",",$emp) ; 

print "Emp name is:$ename  Working city:$ecity\n";

$tax=$ecost * 0.12;
print "Tax = $tax\n";

