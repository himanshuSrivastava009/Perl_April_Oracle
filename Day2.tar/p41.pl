@colors = ("Red","Green","white","Yellow","Blue");

($v1,$v2,$v3,$v4,$v5) = @colors ;

print "\$v1=$v1\n\$v2=$v2\n\$v3=$v3\n\$v4=$v4\n\$v5=$v5\n";

($v1,@arr,$v3,$v4,$v5) = @colors;

print "\$v1=$v1\n";
print "@arr\n";
print "\$v3=$v3\n\$v4=$v4\n\$v5=$v5\n";


@arr=(10,20,30,40,50);

$v1 = @arr ; ## (A)  size of an array is $v1 - 5

($v2) = @arr ; ## (B) 0th index value of an array - 10

