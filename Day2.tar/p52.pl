
%emp = (eid =>"e123",ename =>"Raj",edept =>"sales");

print "$emp{eid}\n";
print "$emp{ename}\n";
print "$emp{edept}\n";
print "\n";

@k = keys(%emp); # to get list of keys from hash

print "@k\n";
