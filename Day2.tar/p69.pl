
open(FH,"InvalidFile") or die($!);

$v = <FH>;
close(FH);
print "$v";

foreach $v (1,2,3){
	print "Test - $v\n";
}

print "Exit from $0 script\n";
