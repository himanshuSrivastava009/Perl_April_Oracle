


print "Login shell name:$ENV{SHELL}\n";

print "command env path:$ENV{PATH}\n";

print "working directory:$ENV{PWD}\n";

print "perlLib path:$ENV{PERL5LIB}\n";

print "pythonpath:$ENV{PYTHONPATH}\n";

