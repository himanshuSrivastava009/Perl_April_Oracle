$r1 = `date`;
print "$r1";

$r2 = system("ps");
print "$r2\n";

#system("systemctl status sshd");

system("ps -e|grep bash|wc -l");
