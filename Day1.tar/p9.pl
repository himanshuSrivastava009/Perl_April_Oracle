$Fname = "/etc/passwd";
$FSIZE = "8KB";
$Futil = 89.42;

print "File name is:$Fname\n";
print "$Fname size is:$FSIZE\n";
print "$Fname Utilization is:$Futil\n";

# multiline string 
print "File name is:$Fname
------------------------------
$Fname size is:$FSIZE
------------------------------
$Fname Utilization is:$Futil\n";
