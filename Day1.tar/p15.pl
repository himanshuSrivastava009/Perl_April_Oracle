$s1 = "Hello";
$s2 = "perl";
$v  = 5;
$s3 = "programming";

#print($s1,$s2,5,$s3,"\n"); OK
print "\n";

print $s1.$s2."5".$s3; # Vs $s1.$s2.5.$s3 ->Error
print "\n";
print "$s1$s2$s3"; # Vs $s1$s2$s3 ->Error
