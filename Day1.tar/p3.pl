print("Welcome to perl programming \n");
#print("Test server1\n");
#print("15\n");
#print(45,"\n");
print("\n"); # empty line
print "Welcome to perl programming \n";
print "Test server1\n";
# single line comment
print "15\n";
print 45,"\n";
# ------ End of the line ------
