
print "Enter n value:";
chomp($n = <>);

if($n >500){
	print "True - $n >500\n";
}else{
	print "False - $n not above 500\n";
}
sleep(5); 

unless($n >500){
	print "False - $n not above 500\n";
}else{
	print "True - $n >500\n";
}
