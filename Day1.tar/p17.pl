print "Enter a login name:";
chomp($name = <>);

if($name eq "root"){
	print "Login is success\n";
}else{
	print "Login is failed\n";
}
