while(1){
	print "---------- system menu ------------
	
	A.  display list files
	B.  process
	C.  filesystem
	D.  quit \n";
	
	print "Enter your choice:";
	chomp($choice = <>);
	
	if ( $choice  eq  "A"  || $choice eq "a") {
		system("ls -l *.log");
	} elsif($choice eq "B"  || $choice eq "b") {
		system("ps");
	} elsif($choice eq "C"  || $choice eq "c") {
		system("df");
	} elsif($choice eq "D"  || $choice eq "d") {
		print "Thank you!\n";
		last;
	} else {
		print("Sorry Invalid Choice\n");
	}
}
