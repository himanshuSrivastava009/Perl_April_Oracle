$count = 10;
while ( $count <5){
	print "Hello\n";
}
print "\n\n";
until($count <5){
	print "From until loop - \$count value is:$count\n";
	$count=$count - 1;
}

