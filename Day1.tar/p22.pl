
chomp($name = `whoami`);

if($name eq  "root"){
   print "Enter a shell name:";
   chomp ($sh_var = <>);
   if( $sh_var eq "bash"  or $sh_var eq  "ksh"){
	$fname = "/etc/bashrc";
   }elsif( $sh_var eq "psh"){
	$fname = "C:\\win_profile";
  } else {
	$sh_var = "/bin/nologin";
	$fname = "/etc/profile";
  }
}else{
    print "Sorry your not a root user\n";
    exit();
}

print "Shell name:$sh_var   Profile File name:$fname\n";

