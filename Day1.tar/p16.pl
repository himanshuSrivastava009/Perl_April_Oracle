$n=56;
if($n == 56){
	print("True block - $n\n");
}else{
	print("False block\n");
}

if($n >50){
	print("True block\n");
}

if($n <50){
  print("True block\n");
}else{
print("False block\n");
}

if("root" eq "root"){
print "Matched\n";
}else{
print "Not-Matched\n";
}
