foreach $var (10,10.34,"data") {
	print "\$var value is:$var\n";
	sleep 1;
}

print "\n\n";

for $var (10,20,30,40,50,60,"A","B"){
	print "\$var value $var\n";
	sleep 1;
}
