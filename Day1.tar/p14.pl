print "Enter a partition name:";
chomp( $p1 = <>);
print "Enter $p1 Size:";
chomp( $s1 = <>);
print "Enter another partition name:";
chomp( $p2 = <>);
print "Enter $p2 Size:";
chomp( $s2 = <>);

$total = $s1 + $s2;

print " 
----------------------------------------------------------------
Partition name:  $p1		Size: $s1 GB
----------------------------------------------------------------
Partition name:  $p2		Size: $s2 GB
----------------------------------------------------------------
		   Total  Size: $total GB
----------------------------------------------------------------\n";
