print("OK1-\n");
print("OK2-\n");
print `date`;
print `uptime`;
/bin/bash<<Abc
echo "Test-1"
echo "Test-2"
echo "Test-3"
ps -f
echo "Exit from shell script"
Abc
print "Back to perl\n";
print "End of the perl script\n";

