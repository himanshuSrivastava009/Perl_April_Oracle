print("Welcome to perl programming \n");
print("Test server1\n");
print("15\n");
print(45,"\n");
print("\n");
print "Welcome to perl programming \n";
print "Test server1\n";
print "15\n";
print 45,"\n";
