$Fname = "/etc/passwd";
$FSIZE = "8KB";
$Futil = 89.42;

print "File name is:$Fname\n";
print "$Fname size is:$FSIZE\n";
print "$Fname Utilization is:$Futil\n";

print "File name is:$fname\n";
