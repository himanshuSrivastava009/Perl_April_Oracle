print "Enter a file name:";
chomp($fname = <>);

if ( -e $fname) {
    if (-f $fname) {
	print "File $fname is a reg.file\n";
	$f = `ls -l $fname`;
	print "$fname file details:-";
	print $f;
    }elsif( -d $fname){
	print "File $fname is a directory file\n";
	$f = `ls -ld  $fname`;
	print "$fname file details:-";
	print $f;
   } else {
	$f = `file $fname`;
	print $f;
   }
}else{
     print "Sorry file name $fname is not exists\n";
}
