

$pin = 1234; 

$count = 0;
while ($count < 3){
	print "Enter a pin Number:";
	chomp($p = <>);
	$count ++ ;
	
	if ($p  == $pin){
		print "Success - pin is matched - $count\n";
		last ; 
	}		
}

if( $p != $pin){
	print "Sorry your pin is blocked\n";
	exit();
}
