# perl multiline comments
# ----------------------------
print("Welcome to perl programming \n");
=begin
print("Test server1\n");
print("15\n");
print(45,"\n");
=cut
print("\n"); # empty line
print "Welcome to perl programming \n";
print "Test server1\n";
# single line comment
print "15\n";
=head
this is multiline
comment in perl script
=cut
print 45,"\n";
<<Abc;
this is another
way to use
multiline comment
in perl program
Abc
print "End of the line\n";
