
print "Display CPU Utilization :-";
$i = 0;

while ( $i < 5){
	system("uptime");
	sleep(2);
	$i=$i+1;  # $i++ ;  $i+=1;
}

print "\n Exit from main script\n";

