print "This is perl script\n";
print `date`;
print `uptime`;
print "Current LoadBalance is:",`uptime`;
