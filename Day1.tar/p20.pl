$name = `whoami`;
#chomp($name);
if($name eq "root"){
	print "OK\n";
}else{
	print "Not-OK\n";
}
