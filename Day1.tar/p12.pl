print "Enter N value:";
$n = <> ; # 56{enter} --> $n = "56\n"
print $n; #  56\n

chomp($n); # remove \n
print $n; # 56

print "\n\n";

print "Enter m value:";
chomp($m = <>);   #  <> - read the input from <STDIN> then chomp() remove \n
print "$m";

