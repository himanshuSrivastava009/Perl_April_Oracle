print "Enter a port Number:";
chomp( $port =<>);

if( $port  >500  and $port <600){
    $app="testApp";
}else{
    $app="demoApp";
}
print "App name is:$app  running port number is:$port\n";

