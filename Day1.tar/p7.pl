$Fsize="2KB"; # Fsize = 2KB <== Error 
$v="data";  # $v = data OK
$count=5;   # $count="5" OK
$utl=98.32; # $utl="98.32" OK
