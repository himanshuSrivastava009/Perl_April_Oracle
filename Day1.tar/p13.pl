print "Enter a file name:";
chomp($fname = <>); 
print "Enter $fname Size:";
chomp($fsize = <>);
print "Enter $fname utilization:";
chomp($futil = <>);

print " File name:$fname
------------------------------
$fname size is:$fsize
------------------------------
$fname utilization is:$futil
------------------------------------\n";
