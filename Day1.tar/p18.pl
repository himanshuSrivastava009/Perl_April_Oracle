print "Enter a port Number:";
chomp( $port =<>);

if( $port  >500 ){
    $app="testApp";
}else{
    $app="demoApp";
}
print "App name is:$app  running port number is:$port\n";

