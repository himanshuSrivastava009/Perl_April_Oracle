

$i = 0;
while ($i < 3){
	print "Enter a login name:";

	chomp($name = <>);

	if ( $name  eq  "root") {
		print "OK\n";
		last; # exit from looping statement
	}else{
		print "Not-Matched\n";
	}

	$i++;
}		
