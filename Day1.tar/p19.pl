print "Enter a shell name:" ;
chomp( $sh = <>);

if( $sh eq "bash"){
     $fname = "/etc/bashrc";
}elsif( $sh eq "ksh"){
     $fname = "/etc/kshrc";
}elsif($sh  eq "csh"){
     $fname = "/etc/cshrc";
}else{
      $sh = "/bin/nologin";
      $fname = "/etc/profile";
}

print "Shell name is:$sh  profile file name is:$fname\n";
