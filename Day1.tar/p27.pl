print "Display CPU Utilization :-\n";
$i = 0;
while ( $i < 5){
	system("uptime");
	sleep(2);
	$i=$i+1;  # $i++ ;  $i+=1;
}
print "\n\n";
print "Current process:-\n";
for($i=0;$i<5;$i++){
	system("ps -f");
	sleep(1);	
}

print "\n Exit from main script\n";

