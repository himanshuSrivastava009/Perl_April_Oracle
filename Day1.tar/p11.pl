
$mylogin = `whoami`;
$myos = `uname`;

print "Login name is:$mylogin";
print "Working os name is:$myos";

chomp($mylogin); # remove \n
chomp($myos);	 # remove \n

print "Login name is:$mylogin";
print "Working os name is:$myos";

print "\n\n"; # empty line
# multiline string
print "Login name is:$mylogin
------------------------------
Working os name is:$myos
------------------------------\n";
