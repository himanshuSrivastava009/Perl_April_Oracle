
$s = "Hello";

# chomp($variable); <== remove \n chars

print "A. $s";
chomp($s);
print "B. $s";
print "\n"; # empty line
$s="Hello";
chop($s);
print "C. $s";
